package rule.ml.api.rule;

/**
 * Class which represents an event. 
 * 
 * @author Adriana
 */
public class Event {

}
