package rule.ml.api.rule;

/**
 * Class which represents an action. 
 * 
 * @author Adriana
 */
public class Action {

}
