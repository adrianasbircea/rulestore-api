package rule.ml.api.rule;

/**
 * Class which represents a condition. 
 * 
 * @author Adriana
 */
public class Condition {

}
