package rule.ml.api.rule;

/**
 * Class which represents a conclusion. 
 * 
 * @author Adriana
 */
public class Conclusion {

}
